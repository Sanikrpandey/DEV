<?php
/**
 * Plugin Name: WEBKUL MARKETPLACE ADONE
 * Plugin URI: http://localhost/woocommerce/
 * Description: Test.
 * Version: 1.0.0
 * Author: Sani Kumar Pandey
 * Text Domain: webkul
 * Domain Path: languages
 * Requires at least: 6.0
 * Requires PHP: 7.2
 *
 * @package WEBKUL MARKETPLACE ADONE
 */

/**
 * Handles email sending
 */
class WK_MARKETPLACE_ADONE {

	/**
	 * Constructor sets up actions
	 */
	public function __construct() {	   		
		add_filter ( 'woocommerce_account_menu_items', array($this, 'affiliate_home_link'), 999 );
	}	

	function affiliate_home_link( $items ){
		if (class_exists('Marketplace')) {			
			// Remove the dashboard menu item, will re-add later
			$logout_link = $items ['dashboard'];
			unset( $items ['dashboard'] );
			$new_item = [
				'dashboard' => $logout_link
			];		
			// Insert top the dashboard item.
			$new_item += $items;
		   
			return $new_item;          
		}
		return $items;
	}

	
}// end of class
new WK_MARKETPLACE_ADONE();
