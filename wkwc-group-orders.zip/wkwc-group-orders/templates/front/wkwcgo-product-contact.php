<?php
/**
 * Add contact template.
 *
 * @package WooCommerce Group Order
 */

defined( 'ABSPATH' ) || exit;

global $wpdb;
?>
<div class="wkmp_attributes">
	<div class="box-header attribute-remove">
		<select class="" name="wkgo_product_detail[<?php echo esc_attr( $i ); ?>][product_id]" id="product_name" title="Product">
			<option value=""><?php esc_html_e( 'Select Product', 'wkmp_seller_auction' ); ?></option>
			<?php
			$args = array(
				'post_type'      => 'product',
				'posts_per_page' => -1,
			);
			$loop = new \WP_Query( $args );
			while ( $loop->have_posts() ) :
				$loop->the_post();
				global $product;
				$products = wc_get_product( get_the_ID() );
				if ( ( $product->get_type() === 'simple' || $product->get_type() === 'virtual' || $product->get_type() === 'variable' ) && get_post_meta( get_the_ID(), '_downloadable', true ) === 'no' ) {
					?>
					<option value="<?php echo esc_attr( get_the_ID() ); ?>"><?php echo esc_html( $products->get_name() ); ?></option>';
					<?php
				}
			endwhile;
			wp_reset_postdata();
			?>
		</select>
		<select class="" name="wkgo_product_detail[<?php echo esc_attr( $i ); ?>][contact_id]" id="contact_name" title="Contact">
			<option value=""><?php esc_html_e( 'Select Contact', 'wkmp_seller_auction' ); ?></option>
			<?php
			$wk_data = $wpdb->get_results( $wpdb->prepare( "select * from {$wpdb->prefix}public_contact_user_list where author_id = %d order by id desc ", get_current_user_id() ), ARRAY_A );
			foreach ( $wk_data as $value ) {
				?>
				<option value="<?php echo esc_attr( $value['id'] ); ?>"><?php echo esc_html( $value['contact_name'] ); ?></option>';
				<?php
			}
			?>
		</select>
		<span class="mp_actions">
			<button class="mp_attribute_remove btn btn-danger"><?php esc_html_e( 'Remove', 'wk-marketplace' ); ?></button>
		</span>
	</div>
</div>
