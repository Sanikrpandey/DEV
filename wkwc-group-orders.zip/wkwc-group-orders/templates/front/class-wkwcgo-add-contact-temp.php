<?php
/**
 * Add contact template.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Templates\Front;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WKWCGO_Add_Contact_Temp' ) ) {

	/**
	 * Contact template handler.
	 */
	class WKWCGO_Add_Contact_Temp {

		/**
		 * Add contact template content.
		 *
		 * @param int $id Contact id.
		 * @return void
		 */
		public function wkwc_go_contact_template( $id ) {
			global $wpdb;

			$wk_posts    = ! empty( $wk_posts ) ? $wk_posts : array();
			$nonce_value = isset( $_POST['wkwcgo_save_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['wkwcgo_save_nonce'] ) ) : '';
			if ( ! empty( $nonce_value ) && ! wp_verify_nonce( $nonce_value, 'wkwcgo_save_nonce_action' ) ) {
				die( esc_html__( 'Security check', 'wkwc-group-order' ) );
			}
			if ( ! empty( $id ) ) {
				$wk_data       = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}public_contact_user_list where id = %d AND author_id = %d", $id, get_current_user_id() ), ARRAY_A );
				$contact_name  = ! empty( $wk_data[0]['contact_name'] ) ? $wk_data[0]['contact_name'] : '';
				$contact_email = ! empty( $wk_data[0]['contact_email'] ) ? $wk_data[0]['contact_email'] : '';
				$contact_phone = ! empty( $wk_data[0]['mobile_no'] ) ? $wk_data[0]['mobile_no'] : '';
			} else {
				$post_data     = ! empty( $_POST ) ? wc_clean( $_POST ) : array();
				$contact_name  = ! empty( $post_data['wk_contact_name'] ) ? $post_data['wk_contact_name'] : '';
				$contact_email = ! empty( $post_data['wk_contact_email'] ) ? $post_data['wk_contact_email'] : '';
				$contact_phone = ! empty( $post_data['wk_contact_phone'] ) ? $post_data['wk_contact_phone'] : '';
			}
			?>
			<form action="" method="post">
				<table class="form-table">
					<tbody>
						<tr valign="top">
							<th scope="row" class="titledesc"><label for="wk_contact_name"><?php esc_html_e( 'Contact Name', 'wkwc-group-order' ); ?></label></th>
							<td class="forminp">
								<input type="text" name="wk_contact_name" id="wk_contact_name" value="<?php echo esc_attr( $contact_name ); ?>" style="min-width:350px;" />
							</td>
						</tr>
						<tr valign="top">
							<th scope="row" class="titledesc"><label for="wk_contact_email"><?php esc_html_e( 'Email', 'wkwc-group-order' ); ?></label></th>
							<td class="forminp">
								<input type="email" name="wk_contact_email" id="wk_contact_email" value="<?php echo esc_attr( $contact_email ); ?>" style="min-width:350px;" />
							</td>
						</tr>
						<tr valign="top">
							<th scope="row" class="titledesc"><label for="wk_contact_phone"><?php esc_html_e( 'Mobile No', 'wkwc-group-order' ); ?></label></th>
							<td class="forminp">
								<input type="number" name="wk_contact_phone" id="wk_contact_phone" value="<?php echo esc_attr( $contact_phone ); ?>" style="min-width:350px;" />
							</td>
						</tr>
						<?php $id = isset( $wk_posts ) ? $id : ''; ?>
						<input type="hidden" name="contact_id" value="<?php echo esc_attr( $id ); ?>" /></p>
					</tbody>
				</table>
				<?php
				wp_nonce_field( 'wkwcgo_save_nonce_action', 'wkwcgo_save_nonce' );
				echo '<p><input type="submit" name="wkwc_add_contact" class="button button-primary" value="' . esc_attr__( 'Save', 'wkwc-group-order' ) . '" /></p>';
				?>
			</form>
			<?php
		}
	}
}
