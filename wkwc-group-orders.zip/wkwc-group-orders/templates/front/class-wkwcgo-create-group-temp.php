<?php
/**
 * Add contact template.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Templates\Front;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WKWCGO_Create_Group_Temp' ) ) {

	/**
	 * Contact template handler.
	 */
	class WKWCGO_Create_Group_Temp {

		/**
		 * Add contact template content.
		 *
		 * @param int $id Contact id.
		 * @return void
		 */
		public function wkwc_go_create_group_template( $id ) {
			global $wpdb;

			$main_page   = get_query_var( 'pagename' );
			$wk_posts    = ! empty( $wk_posts ) ? $wk_posts : array();
			$nonce_value = isset( $_POST['wkwcgo_save_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['wkwcgo_save_nonce'] ) ) : '';
			if ( ! empty( $nonce_value ) && ! wp_verify_nonce( $nonce_value, 'wkwcgo_save_nonce_action' ) ) {
				die( esc_html__( 'Security check', 'wkwc-group-order' ) );
			}
			if ( ! empty( $id ) ) {
				$wk_data             = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wkgo_group_list where id = %d AND author_id = %d", $id, get_current_user_id() ), ARRAY_A );
				$wk_group_status     = ! empty( $wk_data[0]['group_status'] ) ? $wk_data[0]['group_status'] : '';
				$wk_group_name       = ! empty( $wk_data[0]['group_name'] ) ? $wk_data[0]['group_name'] : '';
				$wksa_accept_time    = ! empty( $wk_data[0]['accept_time'] ) ? $wk_data[0]['accept_time'] : '';
				$wksa_pickup_time    = ! empty( $wk_data[0]['pickup_date'] ) ? $wk_data[0]['pickup_date'] : '';
				$wksa_pickup_address = ! empty( $wk_data[0]['pickup_address'] ) ? $wk_data[0]['pickup_address'] : '';
				$product_attributes  = ! empty( maybe_unserialize( $wk_data[0]['product_details'] ) ) ? maybe_unserialize( $wk_data[0]['product_details'] ) : array();
			} else {
				$post_data           = ! empty( $_POST ) ? wc_clean( $_POST ) : array();
				$wk_group_name       = ! empty( $post_data['wk_group_name'] ) ? $post_data['wk_group_name'] : '';
				$wksa_accept_time    = ! empty( $post_data['wksa_accept_time'] ) ? $post_data['wksa_accept_time'] : '';
				$wksa_pickup_time    = ! empty( $post_data['wksa_pickup_time'] ) ? $post_data['wksa_pickup_time'] : '';
				$wksa_pickup_address = ! empty( $post_data['wksa_pickup_address'] ) ? $post_data['wksa_pickup_address'] : '';
				$wk_group_status     = ! empty( $post_data['wk_group_status'] ) ? $post_data['wk_group_status'] : 'Draft';
			}
			?>
			<div class="woocommerce-account woocommerce">
				<div class="wrap wkwc-go">
					<a href="<?php echo esc_url( site_url( $main_page . '/manage-group' ) ); ?>" class="button wkwc-go-button-right" ><?php esc_html_e( 'Back', 'wkwc-group-order' ); ?></a>
					<div class="tablenav top"><strong><?php esc_html_e( 'Create Group', 'wkwc-group-order' ); ?></strong></div>
					<form action="" method="post">
						<table class="form-table">
							<tbody>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<label for="wk_group_status"><?php esc_html_e( 'Group status', 'wkwc-group-order' ); ?></label>
										<span class="required">* </span>
									</th>
									<td class="forminp">
										<select name="wk_group_status" id="wk_group_status">
											<option value="Published" <?php echo( 'Published' === $wk_group_status ) ? 'selected' : ''; ?>><?php esc_html_e( 'Published', 'wkwc-group-order' ); ?></option>
											<option value="Draft" <?php echo( 'Draft' === $wk_group_status ) ? 'selected' : ''; ?>><?php esc_html_e( 'Draft', 'wkwc-group-order' ); ?></option>
										</select>
									</td>
								</tr>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<label for="wk_group_name"><?php esc_html_e( 'Group Name', 'wkwc-group-order' ); ?></label>
										<span class="required">* </span>
									</th>
									<td class="forminp">
										<input class="wkwc-text-width" type="text" name="wk_group_name" id="wk_group_name" value="<?php echo esc_attr( $wk_group_name ); ?>" />
									</td>
								</tr>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<label for="wksa_accept_time"><?php esc_html_e( 'Accept Time', 'wkwc-group-order' ); ?></label>
										<span class="required">* </span>
									</th>
									<td class="forminp"><input class="wksa-date-field" type="datetime-local"  id="wksa_accept_time" name="wksa_accept_time" value="<?php echo esc_attr( $wksa_accept_time ); ?>" /></td>
								</tr>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<label for="wksa_pickup_time"><?php esc_html_e( 'Pickup Date', 'wkwc-group-order' ); ?></label>
										<span class="required">* </span>
									</th>
									<td class="forminp"><input class="wksa-date-field" type="datetime-local"  id="wksa_pickup_time" name="wksa_pickup_time" value="<?php echo esc_attr( $wksa_pickup_time ); ?>" /></td>
								</tr>
								<tr valign="top">
									<th scope="row" class="titledesc">
										<label for="wksa_pickup_address"><?php esc_html_e( 'Pickup Address', 'wkwc-group-order' ); ?></label>
										<span class="required">* </span>
									</th>
									<td class="forminp"><textarea name="wksa_pickup_address" rows="2" id="wksa_pickup_address" class="wkwc-go-textarea"><?php echo esc_html( $wksa_pickup_address ); ?></textarea></td>
								</tr>
								<?php $id = isset( $wk_posts ) ? $id : ''; ?>
								<input type="hidden" name="contact_id" value="<?php echo esc_attr( $id ); ?>" /></p>
							</tbody>
						</table>
						<label><?php esc_html_e( 'Group Contacts And Products', 'wkwc-group-order' ); ?></label>
						<div class="wkmp_container" id="attributestabwk">
							<div class="input_fields_toolbar">
								<button class="btn btn-success add-variant-attribute"><?php esc_html_e( 'Add row', 'wk-marketplace' ); ?></button>
							</div>
							<div class="wk_marketplace_attributes">
								<?php
								if ( ! empty( $product_attributes ) ) {
									$i = 0;
									foreach ( $product_attributes as $key_at => $proatt ) {
										$products     = wc_get_product( $proatt['product_id'] );
										$contact_name = $this->wkwc_get_contact_name_by_id( $proatt['contact_id'] );
										?>
										<div class="wkmp_attributes">
										<div class="box-header attribute-remove">
											<input type="text" class="mp-attributes-name wkmp_product_input" value="<?php echo esc_attr( $products->get_name() ); ?>" readonly>
											<input type="hidden" value="<?php echo esc_attr( $proatt['product_id'] ); ?>" name="wkgo_product_detail[<?php echo esc_attr( $i ); ?>][product_id]">
											<input type="text" class="option wkmp_product_input" value="<?php echo esc_attr( $contact_name ); ?> " readonly>
											<input type="hidden" value="<?php echo esc_attr( $proatt['contact_id'] ); ?>" name="wkgo_product_detail[<?php echo esc_attr( $i ); ?>][contact_id]">

											<span class="mp_actions">
												<button class="mp_attribute_remove btn btn-danger"><?php esc_html_e( 'Remove', 'wk-marketplace' ); ?></button>
											</span>
										</div>
										</div>
										<?php
										++$i;
									}
								}
								?>
							</div>

						</div>
						<?php wp_nonce_field( 'wkwcgo_save_nonce_action', 'wkwcgo_save_nonce' ); ?>
						<input type="submit" name="wkwc_create_group" id="wkwc_create_group" class="button button-primary" value="<?php esc_attr_e( 'Save', 'wkwc-group-order' ); ?>" />
					</form>
				</div>
			</div>
			<?php
		}

		/**
		 * Get contact name by id.
		 *
		 * @param int $cid Contact id.
		 * @return int $contact_name return author id.
		 */
		public function wkwc_get_contact_name_by_id( $cid ) {
			global $wpdb;

			$contact_name = $wpdb->get_var( $wpdb->prepare( "SELECT contact_name FROM {$wpdb->prefix}public_contact_user_list where id=%d", $cid ) );

			return $contact_name;
		}
	}
}
