<?php
/**
 * Group list template.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Templates\Front;

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'WKWCGO_Group_List' ) ) {

	/**
	 * Group list template handler.
	 */
	class WKWCGO_Group_List {

		/**
		 * Helper object.
		 *
		 * @var object $helper Provide the object of helper class.
		 */
		public $helper;

		/** Constructors,  Load action and function */
		public function __construct() {
		}

		/**
		 * Group list.
		 */
		public function wkwc_go_all_group_list() {
			global $wpdb;
			$user_id      = get_current_user_id();
			$wk_data      = $wpdb->get_results( $wpdb->prepare( "select * from {$wpdb->prefix}wkgo_group_list where author_id = %d order by id desc ", $user_id ), ARRAY_A );
			$current_page = get_query_var( 'pagename' );
			?>
			<div class="woocommerce-account woocommerce">
				<div id="main_container">
					<form action="" method="get">
						<?php wp_nonce_field( 'wkwc_group_delete_nonce', 'wkwc_group_delete_nonce_action' ); ?>
						<select id="wkwc-group-bulk-action" class="wkwc-go-select" name="wkwc-group-bulk-action">
							<option value=""><?php esc_html_e( 'Bulk Actions', 'wkwc-group-order' ); ?></option>
							<option value="delete-group"><?php esc_html_e( 'Delete', 'wkwc-group-order' ); ?></option>
						</select>
						<input type="submit" id="wkwcgo-apply-bulk" value="<?php esc_attr_e( 'Apply', 'wkwc-group-order' ); ?>" data-action="bulk"/>
						<a href="<?php echo esc_url( site_url( $current_page . '/create-group' ) ); ?>" class="button wkwc-go-button-right"><?php esc_html_e( 'Create Group', 'wkwc-group-order' ); ?></a>
						<div class="wkwc-go-table-wrap">
							<table class=" wkwc-go-table table table-bordered table-hover">
								<thead>
									<tr>
										<th><input type="checkbox" id="wk-group-cbx-all"></th>
										<th><?php esc_html_e( 'Group Name', 'wkwc-group-order' ); ?></th>
										<th><?php esc_html_e( 'Accept Time', 'wkwc-group-order' ); ?></th>
										<th><?php esc_html_e( 'Status', 'wkwc-group-order' ); ?></th>
										<th><?php esc_html_e( 'Action', 'wkwc-group-order' ); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php $nonce = wp_create_nonce( 'wkwc_group_delete_nonce_action' ); ?>
									<?php foreach ( $wk_data as $value ) : ?>
										<tr>
											<td><input type="checkbox" name="wk-group-cbx[]" class="wk-group-cbx" value="<?php echo esc_attr( $value['id'] ); ?>"></td>
											<td><a href="<?php echo esc_url( site_url( $current_page ) . '/manage-group/view/' . esc_html( $value['id'] ) ); ?>"><?php echo esc_html( $value['group_name'] ); ?></a></td>
											<td><?php echo esc_html( $value['accept_time'] ); ?></td>
											<td><?php echo esc_html( $value['group_status'] ); ?></td>
											<td>
												<a id="" class="mp-action button" href="<?php echo esc_url( site_url( $current_page ) . '/create-group/edit/' . esc_html( $value['id'] ) ); ?>"><span class="dashicons dashicons-edit"></span></a>
												<a id="delprod" class="button  " href="<?php echo esc_url( site_url( $current_page . '/manage-group?delete=' . esc_attr( $value['id'] ) . '&wkwc_group_delete_nonce=' . esc_attr( $nonce ) ) ); ?>" onclick="return confirm('<?php esc_html_e( 'Are you sure ? You can lost some data related to these contact !!', 'wkwc-group-order' ); ?>')" class="ask"><span class="dashicons dashicons-trash" ></span></a>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</form>
				</div>
			</div>
			<?php
		}

		/**
		 * View group.
		 *
		 * @param int $group_id Group ID.
		 * @return void
		 */
		public function wkwc_go_view_group_details( $group_id ) {
			global $wpdb;
			if ( ! empty( $group_id ) ) {
				$wk_data            = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wkgo_group_list where id = %d", $group_id ), ARRAY_A );
				$user               = get_user_by( 'id', $wk_data[0]['author_id'] );
				$group_name         = $wk_data[0]['group_name'];
				$gp_creator_name    = $user->user_login;
				$pickup_add         = $wk_data[0]['pickup_address'];
				$accept_time_end_in = $wk_data[0]['accept_time'];
				$product_details    = ! empty( maybe_unserialize( $wk_data[0]['product_details'] ) ) ? maybe_unserialize( $wk_data[0]['product_details'] ) : array();
				?>
				<div class="wkwcwfp-event-container">
					<div class="wkwcwfp-event-wrapper-fluid">
						<div class="wkwcwfp-event-first-half">
							<div class="wkwcwfp-view-group">
								<table>
									<tr>
										<td><p><strong><?php echo esc_html__( 'Group Name', 'wkwc-group-order' ) . ' : '; ?></strong><?php echo esc_html( $group_name ); ?></p></td>
										<td><p><strong><?php echo esc_html__( 'Pickup Address', 'wkwc-group-order' ) . ' : '; ?></strong><?php echo $pickup_add; ?></p></td>
									</tr>
									<tr>
										<td><p><strong><?php echo esc_html__( 'Group Creator', 'wkwc-group-order' ) . ' : '; ?></strong><?php echo esc_html( $gp_creator_name ); ?></p></td>
										<td rowspan="2"><p><strong><?php echo esc_html__( 'Accept Time', 'wkwc-group-order' ) . ' : '; ?></strong><?php echo esc_html( $accept_time_end_in ); ?></p></td>
									</tr>
								</table>
							</div>
							<div class="wkwc-go-table-wrap">
								<table class=" wkwc-go-table table table-bordered table-hover">
									<thead>
										<tr>
											<td><p><strong><?php echo esc_html__( 'Contacts And Products', 'wkwc-group-order' ) . ' : '; ?></strong></td>
										</tr>
										<tr>
											<th><?php esc_html_e( 'Contacts', 'wkwc-group-order' ); ?></th>
											<th><?php esc_html_e( 'Products', 'wkwc-group-order' ); ?></th>
											<th><?php esc_html_e( 'Quantity', 'wkwc-group-order' ); ?></th>
											<th><?php esc_html_e( 'Request Status', 'wkwc-group-order' ); ?></th>
										</tr>
									</thead>
									<tbody>
									<?php
									foreach ( $product_details as $value ) {
										$products     = wc_get_product( $value['product_id'] );
										$contact_name = $this->wkwc_get_contact_name_by_id( $value['contact_id'] );
										$contact_req  = $this->wkwc_get_contact_accept_detail( $value['contact_id'], $group_id, $value['product_id'] );
										?>
										<tr>
											<td><?php echo esc_html( $contact_name ); ?></td>
											<td><?php echo esc_html( $products->get_name() ); ?></td>
											<td><?php echo esc_html( ! empty( $contact_req[0]['quantity'] ) ? $contact_req[0]['quantity'] : 5 ); ?></td>
											<td><?php echo esc_html( ! empty( $contact_req[0]['request'] ) ? $contact_req[0]['request'] : 'Accept' ); ?></td>
										</tr>
									<?php } ?>
								</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
				<?php
			}
		}

		/**
		 * Get contact name by id.
		 *
		 * @param int $cid Contact id.
		 * @return int $contact_name return author id.
		 */
		public function wkwc_get_contact_name_by_id( $cid ) {
			global $wpdb;

			$contact_name = $wpdb->get_var( $wpdb->prepare( "SELECT contact_name FROM {$wpdb->prefix}public_contact_user_list where id=%d", $cid ) );

			return $contact_name;
		}

		/**
		 * Get contact accept detail.
		 *
		 * @param int $cid Contact id.
		 * @return array
		 */
		public function wkwc_get_contact_accept_detail( $cid, $gp_id, $p_id ) {
			global $wpdb;

			$wk_data = $wpdb->get_results( $wpdb->prepare( "select * from {$wpdb->prefix}wkgo_order_request WHERE group_id = %d AND contact_id = %d AND product_id = %d ORDER BY ID DESC", $gp_id, $cid, $p_id ), ARRAY_A );

			return $wk_data;
		}
	}
}
