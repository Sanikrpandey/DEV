<?php
/**
 * Contact list template.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Templates\Front;

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'WKWCGO_Contact_List' ) ) {

	/**
	 * Contact list template handler.
	 */
	class WKWCGO_Contact_List {

		/**
		 * Helper object.
		 *
		 * @var object $helper Provide the object of helper class.
		 */
		public $helper;

		/** Constructors,  Load action and function */
		public function __construct() {
		}

		/**
		 * Contact list.
		 */
		public function wkwc_go_all_contact_list() {
			global $wpdb;
			$user_id      = get_current_user_id();
			$wk_data      = $wpdb->get_results( $wpdb->prepare( "select * from {$wpdb->prefix}public_contact_user_list where author_id = %d order by id desc ", $user_id ), ARRAY_A );
			$current_page = get_query_var( 'pagename' );
			?>
			<div class="woocommerce-account woocommerce">
				<div id="main_container">
					<form action="" method="get">
						<?php wp_nonce_field( 'wkwc_contact_delete_nonce', 'wkwc_contact_delete_nonce_action' ); ?>
						<select id="wkwc-contact-bulk-action" class="wkwc-go-select" name="wkwc-contact-bulk-action">
							<option value=""><?php esc_html_e( 'Bulk Actions', 'wkwc-group-order' ); ?></option>
							<option value="delete-cnt"><?php esc_html_e( 'Delete', 'wkwc-group-order' ); ?></option>
						</select>
						<input type="submit" id="wkwcgo-apply-bulk" value="<?php esc_attr_e( 'Apply', 'wkwc-group-order' ); ?>" data-action="bulk"/>
						<a href="<?php echo esc_url( site_url( $current_page . '/add-contact/?import=wkwc_contact_csv' ) ); ?>" class="button wkwc-go-button-right"><?php esc_html_e( 'Import by CSV', 'wkwc-group-order' ); ?></a>
						<a href="<?php echo esc_url( site_url( $current_page . '/add-contact' ) ); ?>" class="button wkwc-go-button-right"><?php esc_html_e( 'Add', 'wkwc-group-order' ); ?></a>
						<div class="wkwc-go-table-wrap">
							<table class=" wkwc-go-table table table-bordered table-hover">
								<thead>
									<tr>
										<th><input type="checkbox" id="wk-contact-cbx-all"></th>
										<th><?php esc_html_e( 'Contact Name', 'wkwc-group-order' ); ?></th>
										<th><?php esc_html_e( 'Email', 'wkwc-group-order' ); ?></th>
										<th><?php esc_html_e( 'Action', 'wkwc-group-order' ); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php $nonce = wp_create_nonce( 'wkwc_contact_delete_nonce_action' ); ?>
									<?php foreach ( $wk_data as $value ) : ?>
										<tr>
											<td><input type="checkbox" name="wk-contact-cbx[]" class="wk-contact-cbx" value="<?php echo esc_attr( $value['id'] ); ?>"></td>
											<td><?php echo esc_html( $value['contact_name'] ); ?></td>
											<td><?php echo esc_html( $value['contact_email'] ); ?></td>
											<td>
												<a id="" class="mp-action button" href="<?php echo esc_url( site_url( $current_page ) . '/edit-contact/' . esc_html( $value['id'] ) ); ?>"><span class="dashicons dashicons-edit"></span></a>
												<a id="delprod" class="button  " href="<?php echo esc_url( site_url( $current_page . '/manage-contact?delete=' . esc_attr( $value['id'] ) . '&wkwc_contact_delete_nonce=' . esc_attr( $nonce ) ) ); ?>" onclick="return confirm('<?php esc_html_e( 'Are you sure ? You can lost some data related to these contact !!', 'wkwc-group-order' ); ?>')" class="ask"><span class="dashicons dashicons-trash" ></span></a>
											</td>
										</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</form>
				</div>
			</div>
			<?php
		}
	}
}
