<?php
/**
 * Plugin Name: WooCommerce Group Order
 * Plugin URI: https://webkul.com
 * Description: WooCommerce group order allow users to create groups for a specific product and make a purchase together.
 * Version: 1.0.0
 * Author: Webkul
 * Author URI: https://webkul.com
 * Text Domain: wkwc-group-order
 * Domain Path: /languages
 * License: GNU/GPL for more info see license.txt included with plugin
 * License URI: https://store.webkul.com/license.html
 *
 * Requires at least: 5.0
 * Requires PHP: 7.3
 * WC requires at least: 5.0
 *
 * Requires Plugins: woocommerce
 *
 * @package WooCommerce Group Order
 */

defined( 'ABSPATH' ) || exit(); // Exit if accessed directly.

use WKWCGO\Includes\WKWCGO_File_Handler;
ob_start();
/**Define constraints. */
defined( 'WKWCGO_FILE' ) || define( 'WKWCGO_FILE', __FILE__ );
defined( 'WKWCGO_PATH' ) || define( 'WKWCGO_PATH', plugin_dir_path( __FILE__ ) );
defined( 'WKWCGO_URL' ) || define( 'WKWCGO_URL', plugin_dir_url( __FILE__ ) );

require_once WKWCGO_PATH . 'inc/class-wkwcgo-autoload.php';

// Include the main WKWCGO_File_Handler class.
if ( ! class_exists( 'WKWCGO_File_Handler', false ) ) {
	new WKWCGO_File_Handler();
}

/**
 * Install Schema.
 */
function wkwc_go_install_schema() {
	include_once WKWCGO_PATH . 'includes/class-wkwcgo-install-schema.php';
}
register_activation_hook( WKWCGO_FILE, 'wkwc_go_install_schema' );
load_plugin_textdomain( 'wkwc-group-order', false, basename( __DIR__ ) . '/languages' );
