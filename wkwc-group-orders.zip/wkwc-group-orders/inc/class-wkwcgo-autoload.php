<?php
/**
 * Dynamically loads classes.
 */
namespace WKWCGO;

defined( 'ABSPATH' ) || exit;

/**Check class exists.*/
if ( ! class_exists( 'WKWCGO_Autoload' ) ) {

	/**
	 *  WKWCGO_Autoload class.
	 */
	class WKWCGO_Autoload {

		/**
		 * Wkmsc_Autoload constructor.
		 */
		public function __construct() {
			if ( function_exists( '__autoload' ) ) {
				spl_autoload_register( '__autoload' );
			}
			spl_autoload_register( array( $this, 'wkwc_go_namespace_class_autoload' ) );
		}

		/**
		 * Autoload callback.
		 *
		 * @param string $class_name The name of the class to load.
		 */
		public function wkwc_go_namespace_class_autoload( $class_name ) {
			if ( false === strpos( $class_name, 'WKWCGO' ) ) {
				return;
			}
			$file_parts = explode( '\\', $class_name );
			$filepath   = '';
			$namespace  = $filepath;
			for ( $i = count( $file_parts ) - 1; $i > 0; $i-- ) {
				$current = strtolower( $file_parts[ $i ] );
				$current = str_ireplace( '_', '-', $current );
				if ( count( $file_parts ) - 1 === $i ) {
					if ( strpos( strtolower( $file_parts[ count( $file_parts ) - 1 ] ), 'interface' ) ) {
						$interface_name = explode( '_', $file_parts[ count( $file_parts ) - 1 ] );
						array_pop( $interface_name );
						$interface_name = strtolower( implode( '-', $interface_name ) );
						$file_name      = "interface-{$interface_name}.php";
					} else {
						$file_name = "class-{$current}.php";
					}
				} else {
					$namespace = '/' . esc_attr( $current ) . esc_attr( $namespace );
				}
				$filepath  = trailingslashit( dirname( __DIR__ ) . esc_attr( $namespace ) );
				$filepath .= $file_name;
			}

			// If the file exists in the specified path, then include it.
			if ( file_exists( $filepath ) ) {
				require_once $filepath;
			}
		}
	}
	new WKWCGO_Autoload();
}
