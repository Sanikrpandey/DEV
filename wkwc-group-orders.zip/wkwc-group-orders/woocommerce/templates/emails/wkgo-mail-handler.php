<?php
/**
 * Email Notification email.
 *
 * @package WooCommerce Group Order
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/wallet-notification.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

do_action( 'woocommerce_email_header', $email_heading, $email );

/* translators: %s Customer email */ ?>
<p><?php printf( esc_html__( 'Hi %s,', 'wkwc-group-order' ), esc_html( $customer_email ) ); ?></p>

<?php

if ( ! empty( $email_message ) ) {
	foreach ( $email_message as $key => $message ) {
		?>
		<p><?php echo wp_kses_post( $message ); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
		<?php
	}
}
?>

<p><?php esc_html_e( 'We look forward to seeing you soon.', 'wkwc-group-order' ); ?></p>

<?php
do_action( 'woocommerce_email_footer', $email );
