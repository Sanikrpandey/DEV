<?php
/**
 * Wallet Notification email.
 *
 * @package WooCommerce Group Order
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/plain/wallet-notification.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

echo '= ' . esc_html( $email_heading ) . " =\n\n";

/* translators: %s Customer email */
echo sprintf( esc_html__( 'Hi %s,', 'wkwc-group-order' ), esc_html( $customer_email ) ) . "\n\n";

if ( ! empty( $email_message ) ) {
	foreach ( $email_message as $key => $message ) {
		echo esc_html( $message ) . "\n\n"; //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

esc_html_e( 'We look forward to seeing you soon.', 'wkwc-group-order' ) . "\n\n";

echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

echo wp_kses_post( apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) ) );
