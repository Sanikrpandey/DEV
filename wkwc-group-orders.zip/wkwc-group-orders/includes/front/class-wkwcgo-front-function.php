<?php
/**
 * Front hooks handler.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Includes\Front;

use WKWCGO\Templates\Front;
use WKWCGO\Includes\Front\WKWCGO_Save_Contact;
use WKWCGO\Includes\Front\WKWCGO_Contact_Importer;

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'WKWCGO_Front_Function' ) ) {

	/**
	 * Front hooks.
	 */
	class WKWCGO_Front_Function {

		/**
		 * Insert the new endpoint into the My Account menu.
		 *
		 * @param array $items Menu items.
		 *
		 * @return array
		 */
		public function wkwc_go_new_menu_items( $items ) {
			// Remove the logout menu item.
			$logout = $items['customer-logout'];
			unset( $items['customer-logout'] );
			$items['manage-contact'] = esc_html__( 'Manage Contact', 'wkwc-group-order' );
			$items['manage-group']   = esc_html__( 'Manage Groups', 'wkwc-group-order' );
			// Insert back the logout item.
			$items['customer-logout'] = $logout;

			return $items;
		}

		/**
		 *  Hide page entry tile for seller page.
		 *
		 * @param string $title Page title.
		 */
		public function wkmp_go_hide_page_title( $title ) {
			return ( in_the_loop() && is_page( 'order-request' ) ) ? '' : $title;
		}

		/**
		 * Seller Endpoints.
		 */
		public function wkwc_go_create_wc_endpoints() {
			add_rewrite_endpoint( 'contact-form', EP_ROOT | EP_PAGES );
			add_rewrite_endpoint( 'manage-contact', EP_ROOT | EP_PAGES );
			add_rewrite_endpoint( 'add-contact', EP_ROOT | EP_PAGES );
			add_rewrite_endpoint( 'edit-contact', EP_ROOT | EP_PAGES );
			add_rewrite_endpoint( 'manage-group', EP_ROOT | EP_PAGES );
			add_rewrite_endpoint( 'create-group', EP_ROOT | EP_PAGES );
		}

		/**
		 * View contact.
		 */
		public function wkwc_go_manage_contact() {
			$obj = new Front\WKWCGO_Contact_List();
			$obj->wkwc_go_all_contact_list();
		}

		/**
		 * Seller add contact.
		 */
		public function wkwc_go_manage_add_contact() {
			$main_page = get_query_var( 'pagename' );
			$import    = filter_input( INPUT_GET, 'import', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
			if ( ! empty( $import ) && 'wkwc_contact_csv' === $import ) {
				$obj = new WKWCGO_Contact_Importer();
				$obj->wkwc_go_import_form();
			} else {
				?>
				<div class="woocommerce-account woocommerce">
				<div class="wrap">
				<a href="<?php echo esc_url( site_url( $main_page . '/manage-contact' ) ); ?>" class="button wkwc-go-button-right" ><?php esc_html_e( 'Back', 'wkwc-group-order' ); ?></a>
				<div class="tablenav top"><strong><?php esc_html_e( 'Add Contact', 'wkwc-group-order' ); ?></strong></div>
				<?php
				$id  = get_query_var( 'edit-contact' );
				$obj = new Front\WKWCGO_Add_Contact_Temp();
				$obj->wkwc_go_contact_template( $id );
				echo '</div>';
				echo '</div>';
			}
		}

		/**
		 * Save and update contact.
		 */
		public function wkwc_go_save_contact() {
			new WKWCGO_Save_Contact();
		}

		/**
		 * Save and update contact.
		 */
		public function wkwc_go_sav_group_details() {
			$obj_save_group = new WKWCGO_Save_Group_Details();
			$obj_save_group->wkwc_go_save_group_details();
		}

		/**
		 * View contact.
		 */
		public function wkwc_go_manage_group() {
			$obj   = new Front\WKWCGO_Group_List();
			$url   = get_query_var( 'manage-group', 1 );
			$gp_id = strrchr( $url, '/' );
			$gp_id = substr( $gp_id, 1, strlen( $gp_id ) );
			if ( $gp_id ) {
				$obj->wkwc_go_view_group_details( $gp_id );
			} else {
				$obj->wkwc_go_all_group_list();
			}
		}

		/**
		 * Seller add contact.
		 */
		public function wkwc_go_manage_create_group() {
			$this->wkwc_go_sav_group_details();
			$url  = get_query_var( 'create-group', 1 );
			$c_id = strrchr( $url, '/' );
			$c_id = substr( $c_id, 1, strlen( $c_id ) );
			$obj  = new Front\WKWCGO_Create_Group_Temp();
			$obj->wkwc_go_create_group_template( $c_id );
		}

		/**
		 * Enqueuing front script.
		 *
		 * @return void
		 */
		public function wkwc_go_front_scripts() {
			$wkwc_pc_arr = array(
				'mkt1' => esc_html__( 'Select Contact', 'wk-marketplace' ),
				'mkt2' => esc_html__( 'Attribute value by separating comma eg. a|b|c', 'wk-marketplace' ),
				'mkt3' => esc_html__( 'Select Product', 'wk-marketplace' ),
				'mkt4' => esc_html__( 'Remove', 'wk-marketplace' ),
			);
			$ajax_obj    = array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'ajaxNonce' => wp_create_nonce( 'wkmp-front-nonce' ),
			);
			wp_enqueue_script( 'wkwc_go_front_js', WKWCGO_URL . 'assets/js/front/front.js', array( 'jquery' ), '1.0.0', true );
			wp_enqueue_style( 'wkwc_go_front_css', WKWCGO_URL . 'assets/css/style.css', array( 'dashicons' ), '1.0.0' );

			wp_localize_script(
				'wkwc_go_front_js',
				'wkmpObj',
				array(
					'ajax'             => $ajax_obj,
					'commonConfirmMsg' => esc_html__( 'Are you sure?', 'wk-marketplace' ),
					'mkt_tr'           => $wkwc_pc_arr,
				)
			);
		}

		/**
		 * Product contact attributes.
		 */
		public function wkwc_go_product_contact_attributes() {
			$posted_data = isset( $_POST ) ? wc_clean( $_POST ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Missing
			if ( isset( $posted_data['index'] ) ) {
				$i = $posted_data['index'];
				require_once WKWCGO_PATH . 'templates/front/wkwcgo-product-contact.php';
				die;
			}
		}

		/**
		 * Delete Contact.
		 */
		public function wkwc_go_delete_contact() {
			$sql         = '';
			$user_id     = get_current_user_id();
			$nonce_value = isset( $_GET['wkwc_contact_delete_nonce'] ) ? sanitize_text_field( wp_unslash( $_GET['wkwc_contact_delete_nonce'] ) ) : '';
			if ( ! empty( $nonce_value ) && ! wp_verify_nonce( $nonce_value, 'wkwc_contact_delete_nonce_action' ) ) {
				die( esc_html__( 'Security check', 'wkwc-group-order' ) );
			}
			$get_data  = ! empty( $_GET ) ? wc_clean( $_GET ) : array();
			$cid       = ! empty( $get_data['delete'] ) ? sanitize_text_field( $get_data['delete'] ) : '';
			$authar_id = $this->wkwc_go_authenticate_contact_id( $cid );
			if ( ! empty( $get_data['delete'] ) && (int) $authar_id === $user_id ) {
				$sql = $this->wkwc_go_delete_contact_by_id( $cid );
				if ( $sql ) {
					wc_add_notice( esc_html__( 'Contact deleted successfully.', 'wkwc-group-order' ) );
					wp_safe_redirect( get_permalink( wc_get_page_id( 'myaccount' ) ) . 'manage-contact' );
					exit;
				}
			}
			$current_action = ! empty( $get_data['wkwc-contact-bulk-action'] ) ? sanitize_text_field( $get_data['wkwc-contact-bulk-action'] ) : '';
			if ( ! empty( $current_action ) && ! empty( $get_data['wk-contact-cbx'] ) && is_array( $get_data['wk-contact-cbx'] ) ) {
				foreach ( $get_data['wk-contact-cbx'] as $value ) {
					$authar_id = $this->wkwc_go_authenticate_contact_id( $value );
					if ( (int) $authar_id === $user_id && 'delete-cnt' === $current_action ) {
						$sql  = $this->wkwc_go_delete_contact_by_id( $value );
						$mess = esc_html__( 'Contact deleted successfully.', 'wkwc-group-order' );
					}
				}
				if ( $sql ) {
					wc_add_notice( $mess );
					wp_safe_redirect( get_permalink( wc_get_page_id( 'myaccount' ) ) . 'manage-contact' );
					exit;
				}
			}
		}

		/**
		 * Authenticate Contact author.
		 *
		 * @param int $cid Contact id.
		 * @return int $contact_auth return author id.
		 */
		public function wkwc_go_authenticate_contact_id( $cid ) {
			global $wpdb;

			$contact_auth = $wpdb->get_var( $wpdb->prepare( "SELECT author_id FROM {$wpdb->prefix}public_contact_user_list where id=%s", $cid ) );

			return $contact_auth;
		}

		/**
		 * Delete contact.
		 *
		 * @param int $cid Contact id.
		 */
		public function wkwc_go_delete_contact_by_id( $cid ) {
			global $wpdb;

			$sql = $wpdb->delete( $wpdb->prefix . 'public_contact_user_list', array( 'id' => $cid ) );

			return $sql;
		}

		/**
		 * Contact save form request details.
		 */
		public function wkwcgo_save_form_request_details( $posted_data ) {
			global $wpdb;

			$table_name = $wpdb->prefix . 'wkgo_order_request';
			$wpdb->insert(
				$table_name,
				array(
					'group_id'   => $posted_data['wkgo_group_id'],
					'contact_id' => $posted_data['wkgo_contact_id'],
					'product_id' => $posted_data['wkgo_product_id'],
					'request'    => ! empty( $posted_data['wk_order_request'] ) ? $posted_data['wk_order_request'] : 'Accept',
					'quantity'   => ! empty( $posted_data['wk_changed_product_qt'] ) ? $posted_data['wk_changed_product_qt'] : 5,
				),
				array( '%d', '%d', '%d', '%s', '%d' )
			);
			wc_add_notice( esc_html__( 'Form submitted successfully.', 'wkwc-group-order' ) );
			wp_safe_redirect( $posted_data['_wp_http_referer'] );
			exit;

			// $wpdb->update(
			// $table_name,
			// array(
			// 'request'  => ! empty( $posted_data['wk_order_request'] ) ? ! empty( $posted_data['wk_order_request'] ) : 'Accept',
			// 'quantity' => ! empty( $posted_data['wk_changed_product_qt'] ) ? ! empty( $posted_data['wk_changed_product_qt'] ) : null,
			// ),
			// array(
			// 'id' => $posted_data['wk_order_request'],
			// ),
			// array( '%s', '%d' ),
			// array( '%d' )
			// );
		}
	}
}
