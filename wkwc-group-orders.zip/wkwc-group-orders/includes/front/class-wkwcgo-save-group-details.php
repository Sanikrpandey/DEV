<?php
/**
 * Save contact details.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Includes\Front;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WKWCGO_save_Group_Details' ) ) {

	/**
	 * WKWCGO_Save_Group_Details.
	 */
	class WKWCGO_Save_Group_Details {

		/**
		 * Global database.
		 *
		 * @var $wpdb Provide database connection.
		 */
		public $wpdb;

		/**
		 * Constructors, load action.
		 */
		public function __construct() {
			global $wpdb;
			$this->wpdb = $wpdb;
		}

		/**
		 * Save contact data.
		 *
		 * @param array $data Post data.
		 */
		public function wkwc_go_save_group_details() {
			$post_data = ! empty( $_POST ) ? wc_clean( $_POST ) : array();
			if ( ! empty( $post_data['wkwc_create_group'] ) ) {
				$msg                 = '';
				$wk_group_status     = ! empty( $post_data['wk_group_status'] ) ? $post_data['wk_group_status'] : '';
				$wk_group_name       = ! empty( $post_data['wk_group_name'] ) ? $post_data['wk_group_name'] : '';
				$wksa_accept_time    = ! empty( $post_data['wksa_accept_time'] ) ? $post_data['wksa_accept_time'] : '';
				$wksa_pickup_time    = ! empty( $post_data['wksa_pickup_time'] ) ? $post_data['wksa_pickup_time'] : '';
				$wksa_pickup_address = ! empty( $post_data['wksa_pickup_address'] ) ? $post_data['wksa_pickup_address'] : '';
				$product_attributes  = ! empty( $post_data['wkgo_product_detail'] ) ? $post_data['wkgo_product_detail'] : array();
				if ( ! isset( $post_data['wkwcgo_save_nonce'] ) || ! wp_verify_nonce( $post_data['wkwcgo_save_nonce'], 'wkwcgo_save_nonce_action' ) ) {
					esc_html_e( 'Sorry, your nonce did not verify.', 'wkwc-group-order' );
					die;
				} elseif ( empty( $wk_group_name ) && empty( $wksa_accept_time ) && empty( $wksa_pickup_time ) && empty( $wksa_pickup_address ) ) {
					wc_print_notice( esc_html__( 'All fields are required.', 'wkwc-group-order' ), 'error' );
				} elseif ( empty( $wk_group_name ) ) {
					wc_print_notice( esc_html__( 'Group Name is required.', 'wkwc-group-order' ), 'error' );
				} elseif ( empty( $wksa_accept_time ) ) {
					wc_print_notice( esc_html__( 'Accept Time is required.', 'wkwc-group-order' ), 'error' );
				} elseif ( empty( $wksa_pickup_time ) ) {
					wc_print_notice( esc_html__( 'Pickup Date is required.', 'wkwc-group-order' ), 'error' );
				} elseif ( empty( $wksa_pickup_address ) ) {
					wc_print_notice( esc_html__( 'Pickup Address is required.', 'wkwc-group-order' ), 'error' );
				} elseif ( ! empty( $wk_group_name ) && ! empty( $wksa_accept_time ) && ! empty( $wksa_pickup_time ) && ! empty( $wksa_pickup_address ) ) {
					$group_status    = sanitize_text_field( $wk_group_status );
					$group_name      = sanitize_text_field( $wk_group_name );
					$accept_time     = sanitize_text_field( $wksa_accept_time );
					$pickup_time     = sanitize_text_field( $wksa_pickup_time );
					$pickup_address  = sanitize_text_field( $wksa_pickup_address );
					$user_id         = get_current_user_id();
					$product_details = maybe_serialize( $product_attributes );

					$data = array(
						'author_id'       => $user_id,
						'group_status'    => $group_status,
						'group_name'      => $group_name,
						'accept_time'     => $accept_time,
						'pickup_date'     => $pickup_time,
						'pickup_address'  => $pickup_address,
						'product_details' => $product_details,
					);
					if ( ! empty( trim( $post_data['contact_id'] ) ) ) {
						$this->wkwc_go_update_group_data( $data, $post_data['contact_id'] );
						$group_id = $post_data['contact_id'];
						$msg      = __( 'Group Updated Successfully.', 'wkwc-group-order' );
					} else {
						$group_id = $this->wkwc_go_insert_group_in_db( $data );
						$msg      = __( 'Group Created Successfully.', 'wkwc-group-order' );
					}
				}
				if ( $msg ) {
					if ( $group_id ) {
						$this->wkwc_go_send_email_notification( $group_id, $data );
						wc_add_notice( $msg );
						wp_safe_redirect( get_permalink( wc_get_page_id( 'myaccount' ) ) . 'manage-group' );
						exit;
					}
				}
			}
		}

		/**
		 * Send email notification to the contacts.
		 *
		 * @param mixed $group_id Group ID.
		 * @param array $data Group detail.
		 * @return void
		 */
		public function wkwc_go_send_email_notification( $group_id, $data ) {
			if ( 'Published' === $data['group_status'] ) {
				$group_attributes = ! empty( maybe_unserialize( $data['product_details'] ) ) ? maybe_unserialize( $data['product_details'] ) : array();
				foreach ( $group_attributes as $key => $value ) {
					$url_data        = array(
						'group_id'   => $group_id,
						'contact_id' => $value['contact_id'],
						'product_id' => $value['product_id'],
					);
					$data_string     = json_encode( $url_data );
					$encrypted_token = base64_encode( $data_string );
					$message         = array();
					$message[]       = esc_html__( 'The Group Order request for group ', 'wkwc-group-order' ) . $data['group_name'] . "\n";
					$message[]       = esc_html__( 'Visit the link below for group details', 'wkwc-group-order' ) . "\n";
					$message[]       = esc_url( site_url( 'order-request/add-contact/?token=' . $encrypted_token ) ) . "\n";
					$message[]       = esc_html__( 'Thanks', 'wkwc-group-order' );
					$email_data      = array(
						'msg'     => $message,
						'email'   => $this->wkwc_get_email_by_contact_id( $value['contact_id'] ),
						'heading' => esc_html__( 'Group Order Notification', 'wkwc-group-order' ),
					);
					do_action( 'woocommerce_group_order', $email_data );
				}
			}
		}

		/**
		 * Print notification.
		 *
		 * @param array $data
		 * @return mixed
		 */
		public function wkwc_go_insert_group_in_db( $data ) {
			$table_name = $this->wpdb->prefix . 'wkgo_group_list';
			$sql        = $this->wpdb->insert(
				$table_name,
				$data,
				array( '%d', '%s', '%s', '%s', '%s', '%s', '%s' )
			);

			return $this->wpdb->insert_id;
		}

		/**
		 * Print notification.
		 *
		 * @param string $mess Notification message.
		 * @return mixed
		 */
		public function wkwc_go_update_group_data( $data, $contact_id ) {
			$table_name = $this->wpdb->prefix . 'wkgo_group_list';
			$sql        = $this->wpdb->update(
				$table_name,
				$data,
				array(
					'id' => $contact_id,
				),
				array( '%d', '%s', '%s', '%s', '%s', '%s', '%s' ),
				array( '%d' )
			);

			return $sql;
		}

		/**
		 * Delete Contact.
		 */
		public function wkwc_go_delete_group() {
			$sql         = '';
			$user_id     = get_current_user_id();
			$nonce_value = isset( $_GET['wkwc_group_delete_nonce'] ) ? sanitize_text_field( wp_unslash( $_GET['wkwc_group_delete_nonce'] ) ) : '';
			if ( ! empty( $nonce_value ) && ! wp_verify_nonce( $nonce_value, 'wkwc_group_delete_nonce_action' ) ) {
				die( esc_html__( 'Security check', 'wkwc-group-order' ) );
			}
			$get_data  = ! empty( $_GET ) ? wc_clean( $_GET ) : array();
			$gp_id     = ! empty( $get_data['delete'] ) ? sanitize_text_field( $get_data['delete'] ) : '';
			$authar_id = $this->wkwc_go_authenticate_group_id( $gp_id );
			if ( ! empty( $get_data['delete'] ) && (int) $authar_id === $user_id ) {
				$sql = $this->wkwc_go_delete_group_by_id( $gp_id );
				if ( $sql ) {
					wc_add_notice( esc_html__( 'Group deleted successfully.', 'wkwc-group-order' ) );
					wp_safe_redirect( get_permalink( wc_get_page_id( 'myaccount' ) ) . 'manage-group' );
					exit;
				}
			}
			$current_action = ! empty( $get_data['wkwc-group-bulk-action'] ) ? sanitize_text_field( $get_data['wkwc-group-bulk-action'] ) : '';
			if ( ! empty( $current_action ) && ! empty( $get_data['wk-group-cbx'] ) && is_array( $get_data['wk-group-cbx'] ) ) {
				foreach ( $get_data['wk-group-cbx'] as $value ) {
					$authar_id = $this->wkwc_go_authenticate_group_id( $value );
					if ( (int) $authar_id === $user_id && 'delete-group' === $current_action ) {
						$sql  = $this->wkwc_go_delete_group_by_id( $value );
						$mess = esc_html__( 'Group deleted successfully.', 'wkwc-group-order' );
					}
				}
				if ( $sql ) {
					wc_add_notice( $mess );
					wp_safe_redirect( get_permalink( wc_get_page_id( 'myaccount' ) ) . 'manage-group' );
					exit;
				}
			}
		}

		/**
		 * Authenticate Group author.
		 *
		 * @param int $gp_id Contact id.
		 * @return int $group_auth return author id.
		 */
		public function wkwc_go_authenticate_group_id( $gp_id ) {
			global $wpdb;

			$group_auth = $wpdb->get_var( $wpdb->prepare( "SELECT author_id FROM {$wpdb->prefix}wkgo_group_list where id=%s", $gp_id ) );

			return $group_auth;
		}

		/**
		 * Delete Group.
		 *
		 * @param int $gp_id Group id.
		 */
		public function wkwc_go_delete_group_by_id( $gp_id ) {
			global $wpdb;

			$sql = $wpdb->delete( $wpdb->prefix . 'wkgo_group_list', array( 'id' => $gp_id ) );

			return $sql;
		}

		/**
		 * Authenticate Group author.
		 *
		 * @param int $contact_id Contact id.
		 * @return string $contact_email return email.
		 */
		public function wkwc_get_email_by_contact_id( $contact_id ) {
			global $wpdb;

			$contact_email = $wpdb->get_var( $wpdb->prepare( "SELECT contact_email FROM {$wpdb->prefix}public_contact_user_list where id=%d", $contact_id ) );

			return $contact_email;
		}
	}
}
