<?php
/**
 * Front hooks handler.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Includes\Front;

use WKWCGO\Includes\Front;

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'WKWCGO_Front_Hook' ) ) {

	/**
	 * Front hooks.
	 */
	class WKWCGO_Front_Hook {

		/**
		 * Constructor.
		 */
		public function __construct() {
			$function_handler = new Front\WKWCGO_Front_Function();
			$contact_importer = new WKWCGO_Contact_Importer();
			$obj_save_group   = new WKWCGO_Save_Group_Details();
			add_filter( 'woocommerce_account_menu_items', array( $function_handler, 'wkwc_go_new_menu_items' ) );
			add_filter( 'the_title', array( $function_handler, 'wkmp_go_hide_page_title' ) );
			add_action( 'init', array( $function_handler, 'wkwc_go_create_wc_endpoints' ) );
			add_action( 'woocommerce_account_manage-contact_endpoint', array( $function_handler, 'wkwc_go_manage_contact' ) );
			add_action( 'woocommerce_account_add-contact_endpoint', array( $function_handler, 'wkwc_go_manage_add_contact' ) );
			add_action( 'woocommerce_account_edit-contact_endpoint', array( $function_handler, 'wkwc_go_manage_add_contact' ) );

			add_action( 'woocommerce_account_manage-group_endpoint', array( $function_handler, 'wkwc_go_manage_group' ) );
			add_action( 'woocommerce_account_create-group_endpoint', array( $function_handler, 'wkwc_go_manage_create_group' ) );
			add_action( 'init', array( $obj_save_group, 'wkwc_go_delete_group' ) );

			add_action( 'init', array( $function_handler, 'wkwc_go_save_contact' ) );
			add_action( 'init', array( $function_handler, 'wkwc_go_delete_contact' ) );
			add_action( 'init', array( $contact_importer, 'wkwc_go_handle_upload' ) );
			add_action( 'wp_enqueue_scripts', array( $function_handler, 'wkwc_go_front_scripts' ) );

			add_action( 'wp_ajax_wkwc_go_product_contact_attributes', array( $function_handler, 'wkwc_go_product_contact_attributes' ) );

			add_action( 'wkwcgo_save_contact_form_request_details', array( $function_handler, 'wkwcgo_save_form_request_details' ) );
		}
	}
}
