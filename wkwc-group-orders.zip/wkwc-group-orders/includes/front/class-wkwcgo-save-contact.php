<?php
/**
 * Save contact details.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Includes\Front;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WKWCGO_save_Contact' ) ) {

	/**
	 * WKWCGO_Save_Contact.
	 */
	class WKWCGO_Save_Contact {

		/**
		 * Global database.
		 *
		 * @var $wpdb Provide database connection.
		 */
		public $wpdb;

		/**
		 * Constructors, load action.
		 */
		public function __construct() {
			global $wpdb;
			$this->wpdb = $wpdb;
			$this->wkwc_go_save_contact();
		}

		/**
		 * Save contact data.
		 *
		 * @param array $data Post data.
		 */
		public function wkwc_go_save_contact() {
			$data = ! empty( $_POST ) ? wc_clean( $_POST ) : array();
			if ( ! empty( $data['wkwc_add_contact'] ) ) {
				$msg = '';
				if ( ! isset( $data['wkwcgo_save_nonce'] ) || ! wp_verify_nonce( $data['wkwcgo_save_nonce'], 'wkwcgo_save_nonce_action' ) ) {
					esc_html_e( 'Sorry, your nonce did not verify.', 'wkwc-group-order' );
					exit;
				} elseif ( empty( $data['wk_contact_name'] ) && empty( $data['wk_contact_email'] ) && empty( $data['wk_contact_phone'] ) ) {
					wc_add_notice( esc_html__( 'All fields are required.', 'wkwc-group-order' ), 'error' );
				} elseif ( empty( $data['wk_contact_name'] ) ) {
					wc_add_notice( esc_html__( 'Contact Name is required.', 'wkwc-group-order' ), 'error' );
				} elseif ( empty( $data['wk_contact_email'] ) ) {
					wc_add_notice( esc_html__( 'Email is required.', 'wkwc-group-order' ), 'error' );
				} elseif ( ! empty( $data['wk_contact_name'] ) && ! empty( $data['wk_contact_email'] ) ) {
					$name    = sanitize_text_field( $data['wk_contact_name'] );
					$email   = sanitize_text_field( $data['wk_contact_email'] );
					$phone   = ! empty( $data['wk_contact_phone'] ) ? sanitize_text_field( $data['wk_contact_phone'] ) : null;
					$user_id = get_current_user_id();
					if ( ! empty( trim( $data['contact_id'] ) ) ) {
						$this->wkwc_go_update_contact_db( $user_id, $name, $email, $phone, $data['contact_id'] );
						$msg = __( 'Contact Updated Successfully.', 'wkwc-group-order' );
					} else {
						$this->wkwc_go_add_contact_db( $user_id, $name, $email, $phone );
						$msg = __( 'Contact Added Successfully.', 'wkwc-group-order' );
					}
				}
				if ( $msg ) {
					wc_add_notice( $msg );
					wp_safe_redirect( get_permalink( wc_get_page_id( 'myaccount' ) ) . 'manage-contact' );
					exit;
				}
			}
		}

		/**
		 * Print notification.
		 *
		 * @param mixed $user_id
		 * @param mixed $name
		 * @param mixed $email
		 * @param mixed $phone
		 * @return void
		 */
		public function wkwc_go_add_contact_db( $user_id, $name, $email, $phone ) {
			$table_name = $this->wpdb->prefix . 'public_contact_user_list';
			$this->wpdb->insert(
				$table_name,
				array(
					'author_id'     => $user_id,
					'contact_name'  => $name,
					'contact_email' => $email,
					'mobile_no'     => $phone,
				),
				array( '%d', '%s', '%s', '%d' )
			);
		}

		/**
		 * Print notification.
		 *
		 * @param string $mess Notification message.
		 * @return void
		 */
		public function wkwc_go_update_contact_db( $user_id, $name, $email, $phone, $contact_id ) {
			$table_name = $this->wpdb->prefix . 'public_contact_user_list';

			$sql = $this->wpdb->update(
				$table_name,
				array(
					'author_id'     => $user_id,
					'contact_name'  => $name,
					'contact_email' => $email,
					'mobile_no'     => $phone,
				),
				array(
					'id' => $contact_id,
				),
				array( '%d', '%s', '%s', '%d' ),
				array( '%d' )
			);
		}
	}
}
