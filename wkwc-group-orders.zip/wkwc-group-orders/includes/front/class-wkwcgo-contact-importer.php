<?php
/**
 * Contact Importer.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Includes\Front;

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'WKWCGO_Contact_Importer' ) ) {

	/**
	 * Contact Importer Class.
	 */
	class WKWCGO_Contact_Importer {

		/**
		 * Delimiter
		 *
		 * @var string
		 */
		public $delimiter;

		/**
		 * Class Constructor.
		 *
		 * @return void
		 */
		public function __construct() {
			$this->delimiter = ',';
		}

		/**
		 * Handles the CSV upload and initial parsing of the file to prepare for displaying author import options.
		 *
		 * @throws \Exception Mime_content_type not present.
		 */
		public function wkwc_go_handle_upload() {
			if ( ! empty( $_FILES['import'] ) ) {
				if ( ! empty( $_FILES['import']['name'] ) ) {
					try {
						$file_data    = $_FILES;
						$csv_tmp_name = $file_data['import']['tmp_name'];
						if ( ! function_exists( 'mime_content_type' ) ) {
							throw new \Exception();
						} else {
							$csv_type = mime_content_type( $file_data['import']['tmp_name'] );
							$csv_size = $file_data['import']['size'];
							// Check file size.
							if ( $csv_size > wp_max_upload_size() ) {
								$this->wkwc_go_error_handler( esc_html__( 'Sorry, your csv file is too large.', 'wkwc-group-order' ) );
							}
							$allowed_csv_type = array( 'text/csv', 'application/csv', 'text/plain' );
							// Allow certain file formats.
							if ( ! in_array( $csv_type, $allowed_csv_type, true ) ) {
								$this->wkwc_go_error_handler( esc_html__( 'Invalid file type. The importer supports CSV and TXT file formats.', 'wkwc-group-order' ) );
							}
							// if everything is ok, try to upload file.
							$contact_data = array_map( 'str_getcsv', file( $csv_tmp_name ) );
							if ( ! empty( $contact_data ) ) {
								$handle = fopen( $csv_tmp_name, 'r' );
								if ( false !== $handle ) {
									$this->wkwc_go_import( $handle );
									fclose( $handle );
								}
							}
						}
					} catch ( Exception $ex ) {
						$this->wkwc_go_error_handler( esc_html__( 'To upload the file, enable fileinfo.so or php_fileinfo.dll in the php.ini file', 'wkwc-group-order' ) );
					}
				} else {
					$this->wkwc_go_error_handler( esc_html__( 'Please select CSV FIle to Upload', 'wkwc-group-order' ) );
				}
			}
		}

		/**
		 * Import the file if it exists and is valid.
		 *
		 * @param array $handle handle.
		 * @return void
		 */
		public function wkwc_go_import( $handle ) {
			$header = fgetcsv( $handle, 0, $this->delimiter );
			if ( 3 === count( $header ) ) {
				$loop = 0;
				$row  = fgetcsv( $handle, 0, $this->delimiter );
				while ( false !== $row ) {
					list( $contact_name, $email, $phone_no ) = $row;
					++$loop;
					$contact = array(
						'author_id'     => get_current_user_id(),
						'contact_name'  => wc_clean( $contact_name ),
						'contact_email' => wc_clean( $email ),
						'mobile_no'     => wc_clean( $phone_no ),
					);
					$this->wkwc_go_add_contact_db( $contact );
					$row = fgetcsv( $handle, 0, $this->delimiter );
				}
				$this->wkwc_go_import_end( $loop );
			} else {
				$this->wkwc_go_error_handler( esc_html__( 'The CSV is invalid.', 'wkwc-group-order' ) );
			}
		}

		/**
		 * Performs post-import cleanup of files and the cache.
		 *
		 * @param int $loop loop.
		 * @return void
		 */
		public function wkwc_go_import_end( $loop ) {
			$message = sprintf(
				'%s <strong>' . absint( $loop ) . '</strong> %s <a href="%s" class="button wc-forward">%s</a>',
				/* translators: %s: contact count */
				esc_html__( 'Import complete - imported ', 'wkwc-group-order' ),
				esc_html__( ' contact.', 'wkwc-group-order' ),
				esc_url( get_permalink( wc_get_page_id( 'myaccount' ) ) . 'manage-contact' ),
				esc_html__( 'View contact', 'wkwc-group-order' )
			);
			wc_add_notice( $message );
			wp_safe_redirect( get_permalink( wc_get_page_id( 'myaccount' ) ) . 'add-contact/?import=wkwc_contact_csv' );
			exit;
		}

		/**
		 * Greet.
		 *
		 * @return void
		 */
		public function wkwc_go_import_form() {
			?>
			<h1><?php esc_html_e( 'Import Contact', 'wkwc-group-order' ); ?></h1>
			<div class="narrow">
			<p><?php esc_html_e( 'Hi there! Upload a CSV file containing contact to import the contents into your contact list. Choose a .csv file to upload, then click "Upload file and import".', 'wkwc-group-order' ); ?></p>
			<!--  translators: 1: Link to contact sample file 2: Closing link. -->
			<p><?php printf( /* translators: %s file path */ esc_html__( 'Your CSV needs to include columns in a specific order. %1$sClick here to download a sample%2$s.', 'wkwc-group-order' ), '<a href="' . WKWCGO_URL . 'assets/sample-data/sample_contact_list.csv">', '</a>' ); ?></p>
			<?php
			$bytes        = apply_filters( 'import_upload_size_limit', wp_max_upload_size() );
			$size         = size_format( $bytes );
			$upload_dir   = wp_upload_dir();
			$current_page = get_query_var( 'pagename' );
			if ( ! empty( $upload_dir['error'] ) ) :
				?>
				<div class="error">
					<p><?php esc_html_e( 'Before you can upload your import file, you will need to fix the following error:', 'wkwc-group-order' ); ?></p>
					<p><strong><?php echo esc_html( $upload_dir['error'] ); ?></strong></p>
				</div>
				<?php else : ?>
					<form enctype="multipart/form-data" id="import-upload-form" method="post" action="<?php echo esc_url( site_url( $current_page . '/add-contact/?import=wkwc_contact_csv&step=1' ), 'import-upload' ); ?>">
						<table class="form-table">
							<tbody>
								<tr>
									<th><label for="upload"><?php esc_html_e( 'Choose a file from your computer:', 'wkwc-group-order' ); ?></label></th>
									<td>
										<input type="file" id="upload" name="import" size="25" />
										<input type="hidden" name="action" value="save" />
										<input type="hidden" name="max_file_size" value="<?php echo esc_attr( absint( $bytes ) ); ?>" />
										<small><?php printf( /* translators: %s: maximum upload size */ esc_html__( 'Maximum size: %s', 'wkwc-group-order' ), esc_attr( $size ) ); ?></small>
									</td>
								</tr>
							</tbody>
						</table>
						<input type="hidden" name="delimiter" placeholder="," size="2" />
						<p class="submit"><button type="submit" class="button" value="<?php esc_attr_e( 'Import', 'wkwc-group-order' ); ?>"><?php esc_html_e( 'Import', 'wkwc-group-order' ); ?></button></p>
					</form>
					<?php
				endif;
				?>
			</div>
			<?php
		}

		/**
		 * Print notification.
		 *
		 * @param array $contact
		 * @return void
		 */
		public function wkwc_go_add_contact_db( $contact ) {
			global $wpdb;
			$table_name = $wpdb->prefix . 'public_contact_user_list';
			$wpdb->insert(
				$table_name,
				$contact,
				array( '%d', '%s', '%s', '%d' )
			);
		}

		/**
		 * Error handler
		 *
		 * @param string $error_message error message.
		 * @return void
		 */
		private function wkwc_go_error_handler( $error_message ) {
			wc_add_notice( $error_message, 'error' );
			wp_safe_redirect( get_permalink( wc_get_page_id( 'myaccount' ) ) . 'add-contact/?import=wkwc_contact_csv' );
			exit;
		}
	}
}
