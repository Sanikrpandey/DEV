<?php
/**
 * Order Request.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Includes\Front;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WKWCGO_Order_Request' ) ) {

	/**
	 * WKWCGO_Order_Request.
	 */
	class WKWCGO_Order_Request {

		/**
		 * Constructors, load action.
		 */
		public function __construct() {
			add_shortcode( 'wkwc_order_request', array( $this, 'wkmp_rma_customer_rma_details' ) );
		}

		/**
		 * Rma details form.
		 */
		public function wkmp_rma_customer_rma_details() {
			global $wpdb;
			$get_data = ! empty( $_GET ) ? wc_clean( $_GET ) : array();
			if ( ! empty( $get_data['token'] ) ) {
				$decoded_data    = base64_decode( $get_data['token'] );
				$retrieved_data  = json_decode( $decoded_data, true );
				$group_id        = $retrieved_data['group_id'];
				$contact_id      = $retrieved_data['contact_id'];
				$product_id      = $retrieved_data['product_id'];
				$product         = wc_get_product( $product_id );
				$wk_data         = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}wkgo_group_list where id = %d", $group_id ), ARRAY_A );
				$user            = get_user_by( 'id', $wk_data[0]['author_id'] );
				$group_name      = $wk_data[0]['group_name'];
				$gp_creator_name = $user->user_login;
				$pickup_add      = $wk_data[0]['pickup_address'];
				$product_name    = $product->get_title();
				$product_price   = $product->get_price_html();
				$contact_req     = $this->wkwc_get_contact_accept_detail( $contact_id, $group_id, $product_id );
				$product_qt      = ! empty( $contact_req[0]['quantity'] ) ? $contact_req[0]['quantity'] : 8;
				if ( strtotime( $wk_data[0]['accept_time'] ) >= strtotime( gmdate( 'Y-m-d' ) ) ) {
					$accept_time_end_in = ( strtotime( $wk_data[0]['accept_time'] ) - strtotime( gmdate( 'Y-m-d' ) ) ) / ( 60 * 60 * 24 );
				}
				$post_data = ! empty( $_POST ) ? wc_clean( $_POST ) : array();
				if ( ! empty( $_POST['wkwc_order_request_st'] ) && ! empty( $_POST['wkwcgo_form_request_nonce'] ) && wp_verify_nonce( sanitize_text_field( $_POST['wkwcgo_form_request_nonce'] ), 'wkwcgo_form_request_nonce_action' ) ) {
					do_action( 'wkwcgo_save_contact_form_request_details', $_POST );
				}
				$accept_request = ! empty( $post_data['wk_order_request'] ) ? $post_data['wk_order_request'] : 'Accept';
				$accept_request = ! empty( $contact_req[0]['request'] ) ? $contact_req[0]['request'] : $accept_request
				?>
				<div class="wkwcwfp-event-container">
					<div class="wkwcwfp-event-wrapper-fluid">
						<div class="wkwcwfp-event-first-half">
							<p class="wkwcwfp-event-name"><?php echo esc_html( $group_name ); ?></p>
							<table>
								<tr>
									<td><p><strong><?php echo esc_html__( 'Group Creator', 'wkwc-group-order' ) . ' : '; ?></strong><?php echo esc_html( $gp_creator_name ); ?></p></td>
									<td rowspan="2" class="wkwcwfp-contribution-end-in">
										<p><strong><?php echo esc_html__( 'Accept Time End', 'wkwc-group-order' ) . ' : '; ?></strong><br>
											<?php
											if ( ! isset( $accept_time_end_in ) ) {
												?>
												<span class="wkwcwfp-text-danger"><?php esc_html_e( 'Ended', 'wkwc-group-order' ); ?></span>
												<?php
											} elseif ( isset( $accept_time_end_in ) && 0 === intval( $accept_time_end_in ) ) {
												?>
												<span class="wkwcwfp-text-success"><?php esc_html_e( 'Today', 'wkwc-group-order' ); ?></span>
												<?php
											} else {
												?>
												<span class="wkwcwfp-text-success">
													<?php /* translators: %s for days */ printf( esc_html__( 'in %s day(s)', 'wkwc-group-order' ), wp_kses( (int) $accept_time_end_in, 'wkwc-group-order' ) ); ?>
												</span>
												<?php
											}
											?>
										</p>
									</td>
								</tr>
								<tr><td><p><strong><?php echo esc_html__( 'Product Name', 'wkwc-group-order' ) . ' : '; ?></strong><?php echo esc_html( $product_name ); ?></p></td></tr>
								<tr><td><p><strong><?php echo esc_html__( 'Per Product Price', 'wkwc-group-order' ) . ' : '; ?></strong><?php echo $product_price; ?></p></td></tr>
								<tr><td><p><strong><?php echo esc_html__( 'Product Quantity', 'wkwc-group-order' ) . ' : '; ?></strong><?php echo $product_qt; ?></p></td></tr>
								<tr><td><p><strong><?php echo esc_html__( 'Pickup Address', 'wkwc-group-order' ) . ' : '; ?></strong><?php echo $pickup_add; ?></p></td></tr>
								<tr><td><p><strong><?php echo esc_html__( 'Request', 'wkwc-group-order' ) . ' : '; ?></strong></td></tr>
							</table>
						</div>
						<div class="wkwcwfp-event-second-half">
							<form action="" method="post">
								<?php wp_nonce_field( 'wkwcwfp_event_action', 'wkwcwfp_event_nonce' ); ?>
								<input type="hidden" name="wkgo_group_id" value="<?php echo esc_attr( $group_id ); ?>" >
								<input type="hidden" name="wkgo_product_id" value="<?php echo esc_attr( $product_id ); ?>" >
								<input type="hidden" name="wkgo_contact_id" value="<?php echo esc_attr( $contact_id ); ?>" >
								<div>
									<span class="wkwc-radio">
										<input type="radio" id="wk_accept_request" name="wk_order_request" value="Accept" <?php echo( 'Accept' === $accept_request ) ? 'checked' : ''; ?>>
										<label for="wk_accept_request"><?php esc_html_e( 'Accept', 'wkwc-group-order' ); ?></label>
									</span>
									<span class="wkwc-radio">
										<input type="radio" id="wk_decline_request" name="wk_order_request" value="Decline" <?php echo( 'Decline' === $accept_request ) ? 'checked' : ''; ?>>
										<label for="wk_decline_request"><?php esc_html_e( 'Decline', 'wkwc-group-order' ); ?></label>
									</span class="wkwc-radio">
									<span class="wkwc-radio">
										<input type="radio" id="wk_change_qt" name="wk_change_qt" value="change_qt">
										<label for="wk_change_qt"><?php esc_html_e( 'Change Quantity', 'wkwc-group-order' ); ?></label>
									</span>
									<span class="wkwc-radio wkwc-new-quantity">
										<input type="hidden" name="wk_changed_product_qt" value="<?php echo esc_attr( $product_qt ); ?>" >
									</span>
								</div><br>
								<?php wp_nonce_field( 'wkwcgo_form_request_nonce_action', 'wkwcgo_form_request_nonce' ); ?>
								<input type="submit" name="wkwc_order_request_st" id="wkwc_order_request_st" class="wkwcwfp-button wkwcwfp-withdraw-button" value="<?php esc_attr_e( 'Submit', 'wkwc-group-order' ); ?>" />
							</form>
						</div>
					</div>
				</div>
				<?php
			}
		}

		/**
		 * Get contact accept detail.
		 *
		 * @param int $cid Contact id.
		 * @return array
		 */
		public function wkwc_get_contact_accept_detail( $cid, $gp_id, $p_id ) {
			global $wpdb;

			$wk_data = $wpdb->get_results( $wpdb->prepare( "select * from {$wpdb->prefix}wkgo_order_request WHERE group_id = %d AND contact_id = %d AND product_id = %d ORDER BY ID DESC", $gp_id, $cid, $p_id ), ARRAY_A );

			return $wk_data;
		}
	}
}
