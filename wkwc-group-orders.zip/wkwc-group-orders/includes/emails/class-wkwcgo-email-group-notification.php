<?php
/**
 * Group Order notifications.
 *
 * @package WooCommerce Group Order
 */

namespace WKWCGO\Includes\Emails;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WKWCGO_Email_Group_Notification' ) ) {

	/**
	 * Email Group Order Notification
	 */
	class WKWCGO_Email_Group_Notification extends \WC_Email {

		/**
		 * Email method ID.
		 *
		 * @var String
		 */
		public $footer;

		/**
		 * Constructor.
		 */
		public function __construct() {

			$this->id             = 'group_notification';
			$this->title          = esc_html__( 'Group Order Notification', 'wkwc-group-order' );
			$this->heading        = esc_html__( 'Group Order Notification', 'wkwc-group-order' );
			$this->subject        = '[' . get_option( 'blogname' ) . ']' . esc_html__( ' Group Order Notification', 'wkwc-group-order' );
			$this->description    = esc_html__( 'On using group order this mail is sent to contact ', 'wkwc-group-order' );
			$this->template_html  = 'emails/wkgo-mail-handler.php';
			$this->template_plain = 'emails/plain/wkgo-mail-handler.php';
			$this->template_base  = WKWCGO_PATH . 'woocommerce/templates/';
			$this->footer         = esc_html__( 'Thanks for choosing Group Order.', 'wkwc-group-order' );

			add_action( 'woocommerce_group_order_notification', array( $this, 'trigger' ), 10, 1 );

			// Call parent constructor.
			parent::__construct();

			// Other settings.
			$this->recipient = $this->get_option( 'recipient' );

			if ( ! $this->recipient ) {
				$this->recipient = get_option( 'admin_email' );
			}
		}

		/**
		 * Trigger.
		 *
		 * @param array $data data.
		 *
		 * @return array
		 */
		public function trigger( $data ) {
			if ( empty( $data ) ) {
				return;
			} else {
				$this->email_message = $data['msg'];
				$this->recipient     = $data['email'];
				$this->heading       = $data['heading'];
			}
			if ( $this->is_enabled() && $this->get_recipient() ) {
				if ( ! empty( $data['attachment'] ) ) {
					$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $data['attachment'] );
				} else {
					$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
				}
			}
		}

		/**
		 * Get content html.
		 *
		 * @return string
		 */
		public function get_content_html() {
			return wc_get_template_html(
				$this->template_html,
				array(
					'email_heading'  => $this->get_heading(),
					'email_message'  => $this->email_message,
					'customer_email' => $this->get_recipient(),
					'blogname'       => $this->get_blogname(),
					'sent_to_admin'  => false,
					'plain_text'     => false,
					'email'          => $this,
				),
				'',
				$this->template_base
			);
		}

		/**
		 * Get content plain.
		 *
		 * @return string
		 */
		public function get_content_plain() {
			return wc_get_template_html(
				$this->template_plain,
				array(
					'email_heading'  => $this->get_heading(),
					'email_message'  => $this->email_message,
					'customer_email' => $this->get_recipient(),
					'blogname'       => $this->get_blogname(),
					'sent_to_admin'  => false,
					'plain_text'     => true,
					'email'          => $this,
				),
				'',
				$this->template_base
			);
		}
	}
}
