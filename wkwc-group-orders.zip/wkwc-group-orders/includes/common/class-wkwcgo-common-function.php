<?php
/**
 * Common functions.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Includes\Common;

use WKWCGO\Includes\Emails\WKWCGO_Email_Group_Notification;

if ( ! class_exists( 'WKWCGO_Common_Function' ) ) {

	/**
	 * Common Function Class.
	 */
	class WKWCGO_Common_Function {

		/**
		 * Constructor
		 */
		public function __construct() {
			add_filter( 'woocommerce_email_classes', array( $this, 'wkwc_go_add_new_email_notification' ), 10, 1 );
			add_filter( 'woocommerce_email_actions', array( $this, 'wkwc_go_add_notification_actions' ) );
		}

		/**
		 * Add notification.
		 *
		 * @param array $actions actions.
		 *
		 * @return array.
		 */
		public function wkwc_go_add_notification_actions( $actions ) {
			$actions[] = 'woocommerce_group_order';

			return $actions;
		}

		/**
		 * Adding notification class.
		 *
		 * @param array $email_classes email classes.
		 *
		 * @return array.
		 */
		public function wkwc_go_add_new_email_notification( $email_classes ) {
			$email_classes['WKWCGO_Email_Group_Notification'] = new WKWCGO_Email_Group_Notification();

			return $email_classes;
		}
	}
}
