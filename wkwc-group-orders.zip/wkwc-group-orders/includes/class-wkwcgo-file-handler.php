<?php
/**
 * File Handler.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Includes;

use WKWCGO\Includes\Front;
use WKWCGO\Includes\Common;

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'WKWCGO_File_Handler' ) ) {

	/**
	 * WKWCGO_File_Handler.
	 */
	class WKWCGO_File_Handler {

		/**
		 * Load construct.
		 */
		public function __construct() {
			// if ( ! is_admin() ) {
				new Front\WKWCGO_Front_Hook();
			// }
			new Front\WKWCGO_Order_Request();
			new Common\WKWCGO_Common_Function();
		}
	}
}
