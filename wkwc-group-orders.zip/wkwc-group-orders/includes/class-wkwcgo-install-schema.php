<?php
/**
 * Install schema.
 *
 * @package WooCommerce Group Order
 */
namespace WKWCGO\Includes;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WKWCGO_Install_Schema' ) ) {

	/**
	 * Activation class
	 */
	class WKWCGO_Install_Schema {

		/**
		 * Global database.
		 *
		 * @var $wpdb Provide database connection.
		 */
		public $wpdb;

		/**
		 * Constructor.
		 */
		public function __construct() {
			global $wpdb;
			$this->wpdb = $wpdb;
			$this->wkwc_go_create_schema();
			$this->wkwc_go_create_order_request_page();
		}

		/**
		 * Create ram table.
		 */
		public function wkwc_go_create_schema() {
			$charset_collate = $this->wpdb->get_charset_collate();

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';

			$table1 = "CREATE TABLE IF NOT EXISTS {$this->wpdb->prefix}public_contact_user_list (
				`id` bigint(20) NOT NULL AUTO_INCREMENT,
				`author_id` bigint(20) NOT NULL,
				`contact_name` varchar(255) NOT NULL,
				`contact_email` varchar(100) NOT NULL,
				`mobile_no` bigint(20),
				PRIMARY KEY (id)
			) $charset_collate;";

			dbDelta( $table1 );

			$table2 = "CREATE TABLE IF NOT EXISTS {$this->wpdb->prefix}wkgo_group_list (
				`id` bigint(20) NOT NULL AUTO_INCREMENT,
				`author_id` bigint(20) NOT NULL,
				`group_status` varchar(20) NOT NULL,
				`group_name` varchar(255) NOT NULL,
				`accept_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
				`pickup_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
				`pickup_address` varchar(255) NOT NULL,
				`product_details` longtext,
				PRIMARY KEY (id)
			) $charset_collate;";

			dbDelta( $table2 );

			$table3 = "CREATE TABLE IF NOT EXISTS {$this->wpdb->prefix}wkgo_order_request (
				`id` bigint(20) NOT NULL AUTO_INCREMENT,
				`group_id` bigint(20) NOT NULL,
				`contact_id` bigint(20) NOT NULL,
				`product_id` bigint(20) NOT NULL,
				`request` varchar(20),
				`quantity` bigint(50),
				PRIMARY KEY (id)
			) $charset_collate;";

			dbDelta( $table3 );
		}

		/**
		 * Create Coupon Listing Page on activation
		 *
		 * @return void
		 */
		public function wkwc_go_create_order_request_page() {
			$pages = array(
				'order-request' => array(
					'title'   => esc_html__( 'Order Request', 'wkmp_seller_auction' ),
					'content' => '[wkwc_order_request]',
				),
			);
			foreach ( $pages as $key => $value ) {
				$page    = get_page_by_path( $key );
				$page_id = ! empty( $page->ID ) ? $page->ID : 0;
				if ( empty( $page_id ) ) {
					$page_data = array(
						'post_status'    => 'publish',
						'post_type'      => 'page',
						'post_author'    => get_current_user_id(),
						'post_name'      => $key,
						'post_title'     => $value['title'],
						'post_content'   => $value['content'],
						'comment_status' => 'closed',
						'page_template'  => 'template-fullwidth.php',
					);
					$page_id   = wp_insert_post( $page_data );
					if ( $page_id > 0 && 'order-request' === $key ) {
						update_option( 'wkwc_order_request', $page_id, 'no' );
					}
				}
			}
		}
	}
	new WKWCGO_Install_Schema();
}
