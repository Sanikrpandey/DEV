/*
front end JS File.
*/

"use strict";
var wkwc_go = jQuery.noConflict();
var count = 2;

(function (wkwc_go) {
    wkwc_go(document).ready(function () {

        // Select all checkbox in head on selecting all entries checkboxes in body in front seller tables.
        wkwc_go('table tbody td input[type=checkbox]').on('click', function () {
            let checkedInput = wkwc_go('table tbody td input[type=checkbox]:checked').length;
            let total = wkwc_go("table tbody td input[type=checkbox]").length;
            if(total === checkedInput) {
                wkwc_go("#wk-contact-cbx-all").prop("checked", true);
                wkwc_go("#wk-group-cbx-all").prop("checked", true);
            } else {
                wkwc_go("#wk-contact-cbx-all").prop("checked", false);
                wkwc_go("#wk-group-cbx-all").prop("checked", false);
            }
        });

        if (wkwc_go('#wk-contact-cbx-all').length) {
            wkwc_go('#wk-contact-cbx-all').change(function () {
                wkwc_go(this).is(":checked") ? wkwc_go('.wk-contact-cbx').prop("checked", true) : wkwc_go('.wk-contact-cbx').prop("checked", false);
            });
        }

        if (wkwc_go('#wk-group-cbx-all').length) {
            wkwc_go('#wk-group-cbx-all').change(function () {
                wkwc_go(this).is(":checked") ? wkwc_go('.wk-group-cbx').prop("checked", true) : wkwc_go('.wk-group-cbx').prop("checked", false);
            });
        }

        //attribute dynamic fields
        wkwc_go(document).on('click', '.add-variant-attribute', function (e) {
            e.preventDefault();
            var wrapper = wkwc_go(".wk_marketplace_attributes");
            var attribute_no = wkwc_go("div.wk_marketplace_attributes > div.wkmp_attributes").length;
            var x = attribute_no;
            wkwc_go.ajax({
                type: 'POST',
                url: wkmpObj.ajax.ajaxUrl,
                data: {
                    action: "wkwc_go_product_contact_attributes",
                    index: x,
                    wkmp_nonce: wkmpObj.ajax.ajaxNonce,
                },
                success: function (data) {
                    wkwc_go(wrapper).append(data);
                    x++;
                }
            });
    	});

        wkwc_go(".wk_marketplace_attributes").on("click", ".mp_attribute_remove", function (e) { //user click on remove text
    		e.preventDefault();
    		wkwc_go(this).parent().parent().parent().remove();
        });

        wkwc_go('#wk_change_qt').on('click', function () {
            let wrapper = wkwc_go(".wkwc-new-quantity");
            var html = '';
            html += '<label for="wk_changed_product_qt">Enter Quantity</label>';
            html += '<input type="number" id="wk_changed_product_qt" name="wk_changed_product_qt" min="1" value="">';
            wkwc_go(wrapper).append(html);
        });
    });
})(wkwc_go);

