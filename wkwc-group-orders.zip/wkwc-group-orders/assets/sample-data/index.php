<?php
/**
 * Silence is golden
 *
 * @package WooCommerce Group Order
 */
